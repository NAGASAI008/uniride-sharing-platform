cd ../kafka_2.12-3.9.0/
bin/kafka-server-start.sh config/kraft/reconfig-server.properties
